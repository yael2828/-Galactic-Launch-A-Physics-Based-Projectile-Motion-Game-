// src/utils/helpers.js

import { PLANETS } from './constants';

export const updateGivenSpeed = (planet) => {
  const g = PLANETS[planet].gravity;
  let minSpeed, maxSpeed;
  
  if (g <= 2) {
    minSpeed = 15;
    maxSpeed = 30;
  } else if (g <= 5) {
    minSpeed = 20;
    maxSpeed = 35;
  } else if (g <= 10) {
    minSpeed = 25;
    maxSpeed = 40;
  } else {
    minSpeed = 30;
    maxSpeed = 50;
  }
  
  const newSpeed = Math.random() * (maxSpeed - minSpeed) + minSpeed;
  return newSpeed;
};

export const randomizeTarget = () => {
  return {
    x: Math.random() * 250 + 500,
    y: Math.random() * 280 + 50
  };
};

export const generateStars = (canvasWidth, canvasHeight) => {
  const newStars = [];
  for (let i = 0; i < 200; i++) {
    newStars.push({
      x: Math.random() * canvasWidth,
      y: Math.random() * 280,
      size: Math.random() * 2 + 0.5,
      opacity: Math.random() * 0.5 + 0.5,
      speedX: (Math.random() - 0.5) * 0.5,
      speedY: (Math.random() - 0.5) * 0.5,
      twinkleSpeed: Math.random() * 0.05 + 0.01
    });
  }
  return newStars;
};

export const calculateHitAccuracy = (distanceFromCenter, targetRadius) => {
  let points, accuracy;
  if (distanceFromCenter < targetRadius * 0.15) {
    points = 20;
    accuracy = "BULLSEYE! 🎯";
  } else if (distanceFromCenter < targetRadius * 0.4) {
    points = 15;
    accuracy = "Inner Ring!";
  } else if (distanceFromCenter < targetRadius * 0.7) {
    points = 10;
    accuracy = "Good Shot!";
  } else {
    points = 5;
    accuracy = "Hit!";
  }
  return { points, accuracy };
};