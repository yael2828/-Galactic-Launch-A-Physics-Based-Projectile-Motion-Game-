// src/utils/PhysicsCalculator.js

export const PhysicsCalculator = {
  calculateAngleFromVelocity(distance, height, velocity, gravity) {
    const g = gravity;
    const v = velocity;
    const x = distance;
    const h = height;
    const solutions = [];
    
    const vSquared = v * v;
    const vFourth = vSquared * vSquared;
    const discriminant = vFourth - g * (g * x * x + 2 * h * vSquared);
    
    const steps = [];
    steps.push("📐 SOLVING FOR ANGLE");
    steps.push("━━━━━━━━━━━━━━━━━━━━━━━━━━");
    steps.push("\n📋 Given:");
    steps.push(`   Distance (x) = ${x.toFixed(2)} m`);
    steps.push(`   Height (h) = ${h.toFixed(2)} m`);
    steps.push(`   Velocity (v₀) = ${v.toFixed(2)} m/s`);
    steps.push(`   Gravity (g) = ${g} m/s²`);
    
    steps.push("\n📐 Formula:");
    steps.push("   tan(θ) = [v₀² ± √(v₀⁴ - g(gx² + 2hv₀²))] / (gx)");
    
    steps.push("\n🔢 Step 1: Calculate v₀²");
    steps.push(`   v₀² = ${v}² = ${vSquared.toFixed(2)}`);
    
    steps.push("\n🔢 Step 2: Calculate v₀⁴");
    steps.push(`   v₀⁴ = (${vSquared.toFixed(2)})² = ${vFourth.toFixed(2)}`);
    
    steps.push("\n🔢 Step 3: Calculate discriminant");
    steps.push(`   Discriminant = v₀⁴ - g(gx² + 2hv₀²)`);
    steps.push(`   = ${vFourth.toFixed(2)} - ${g}(${g}×${x}² + 2×${h}×${vSquared.toFixed(2)})`);
    steps.push(`   = ${vFourth.toFixed(2)} - ${g}(${(g * x * x).toFixed(2)} + ${(2 * h * vSquared).toFixed(2)})`);
    steps.push(`   = ${discriminant.toFixed(2)}`);
    
    if (discriminant < 0) {
      steps.push("\n❌ Discriminant < 0: No real solution!");
      steps.push("   Target is unreachable with given velocity.");
      return { solutions: [], steps: steps.join('\n') };
    }
    
    const sqrtDiscriminant = Math.sqrt(discriminant);
    steps.push(`   √Discriminant = ${sqrtDiscriminant.toFixed(4)}`);
    
    const tanThetaHigh = (vSquared + sqrtDiscriminant) / (g * x);
    const tanThetaLow = (vSquared - sqrtDiscriminant) / (g * x);
    
    steps.push("\n🔢 Step 4: Calculate tan(θ) for both trajectories");
    steps.push(`   tan(θ_low) = (${vSquared.toFixed(2)} - ${sqrtDiscriminant.toFixed(4)}) / (${g}×${x})`);
    steps.push(`   tan(θ_low) = ${tanThetaLow.toFixed(4)}`);
    steps.push(`   tan(θ_high) = (${vSquared.toFixed(2)} + ${sqrtDiscriminant.toFixed(4)}) / (${g}×${x})`);
    steps.push(`   tan(θ_high) = ${tanThetaHigh.toFixed(4)}`);
    
    steps.push("\n🔢 Step 5: Calculate angles");
    
    for (let [tanTheta, arcType] of [[tanThetaLow, 'low'], [tanThetaHigh, 'high']]) {
      if (tanTheta >= 0) {
        const angleRad = Math.atan(tanTheta);
        const angleDeg = angleRad * 180 / Math.PI;
        
        if (angleDeg >= 0 && angleDeg <= 90) {
          const cosTheta = Math.cos(angleRad);
          const sinTheta = Math.sin(angleRad);
          const vx = v * cosTheta;
          const vy = v * sinTheta;
          const t = vx > 0 ? x / vx : 0;
          const calculatedHeight = vy * t - 0.5 * g * t * t;
          const error = Math.abs(calculatedHeight - h);
          
          steps.push(`   θ_${arcType} = arctan(${tanTheta.toFixed(4)}) = ${angleDeg.toFixed(2)}°`);
          
          if (error < 0.1) {
            solutions.push({
              angle: angleDeg,
              speed: v,
              error,
              time: t,
              vx,
              vy,
              arcType
            });
          }
        }
      }
    }
    
    if (solutions.length > 0) {
      steps.push("\n✅ SOLUTION FOUND!");
      solutions.forEach((sol, idx) => {
        steps.push(`\n   Solution ${idx + 1} (${sol.arcType} arc):`);
        steps.push(`   Angle = ${sol.angle.toFixed(2)}°`);
        steps.push(`   vₓ = ${sol.vx.toFixed(3)} m/s`);
        steps.push(`   vᵧ = ${sol.vy.toFixed(3)} m/s`);
        steps.push(`   Time = ${sol.time.toFixed(3)} s`);
      });
    }
    
    solutions.sort((a, b) => a.error - b.error || (a.arcType === 'low' ? -1 : 1));
    return { solutions, steps: steps.join('\n') };
  },
  
  calculateVelocityFromAngle(distance, height, angleDeg, gravity) {
    const g = gravity;
    const x = distance;
    const h = height;
    const angleRad = angleDeg * Math.PI / 180;
    const cosTheta = Math.cos(angleRad);
    const sinTheta = Math.sin(angleRad);
    const tanTheta = Math.tan(angleRad);
    
    const steps = [];
    steps.push("⚡ SOLVING FOR VELOCITY");
    steps.push("━━━━━━━━━━━━━━━━━━━━━━━━━━");
    steps.push("\n📋 Given:");
    steps.push(`   Distance (x) = ${x.toFixed(2)} m`);
    steps.push(`   Height (h) = ${h.toFixed(2)} m`);
    steps.push(`   Angle (θ) = ${angleDeg.toFixed(2)}°`);
    steps.push(`   Gravity (g) = ${g} m/s²`);
    
    steps.push("\n📐 Formula:");
    steps.push("   v₀² = (gx²) / (2cos²θ(x·tanθ - h))");
    
    steps.push("\n🔢 Step 1: Calculate trigonometric values");
    steps.push(`   cos(${angleDeg.toFixed(2)}°) = ${cosTheta.toFixed(4)}`);
    steps.push(`   sin(${angleDeg.toFixed(2)}°) = ${sinTheta.toFixed(4)}`);
    steps.push(`   tan(${angleDeg.toFixed(2)}°) = ${tanTheta.toFixed(4)}`);
    
    steps.push("\n🔢 Step 2: Calculate denominator");
    const denominator = x * tanTheta - h;
    steps.push(`   x·tanθ - h = ${x}×${tanTheta.toFixed(4)} - ${h}`);
    steps.push(`   = ${(x * tanTheta).toFixed(2)} - ${h}`);
    steps.push(`   = ${denominator.toFixed(2)}`);
    
    if (denominator <= 0) {
      steps.push("\n❌ Denominator ≤ 0: No valid solution!");
      steps.push("   Target cannot be reached at this angle.");
      return { solution: null, steps: steps.join('\n') };
    }
    
    steps.push("\n🔢 Step 3: Calculate v₀²");
    const v0Squared = (g * x * x) / (2 * cosTheta * cosTheta * denominator);
    steps.push(`   v₀² = (${g}×${x}²) / (2×${cosTheta.toFixed(4)}²×${denominator.toFixed(2)})`);
    steps.push(`   v₀² = ${(g * x * x).toFixed(2)} / ${(2 * cosTheta * cosTheta * denominator).toFixed(2)}`);
    steps.push(`   v₀² = ${v0Squared.toFixed(2)}`);
    
    if (v0Squared <= 0) {
      steps.push("\n❌ v₀² ≤ 0: No valid solution!");
      return { solution: null, steps: steps.join('\n') };
    }
    
    const v0 = Math.sqrt(v0Squared);
    steps.push("\n🔢 Step 4: Calculate v₀");
    steps.push(`   v₀ = √${v0Squared.toFixed(2)} = ${v0.toFixed(2)} m/s`);
    
    if (v0 < 1 || v0 > 50) {
      steps.push("\n❌ Velocity out of range (1-50 m/s)");
      return { solution: null, steps: steps.join('\n') };
    }
    
    const vx = v0 * cosTheta;
    const vy = v0 * sinTheta;
    const t = vx > 0 ? x / vx : 0;
    const calculatedHeight = vy * t - 0.5 * g * t * t;
    const error = Math.abs(calculatedHeight - h);
    
    steps.push("\n🔢 Step 5: Verify solution");
    steps.push(`   vₓ = ${v0.toFixed(2)}×${cosTheta.toFixed(4)} = ${vx.toFixed(3)} m/s`);
    steps.push(`   vᵧ = ${v0.toFixed(2)}×${sinTheta.toFixed(4)} = ${vy.toFixed(3)} m/s`);
    steps.push(`   Time = ${x} / ${vx.toFixed(3)} = ${t.toFixed(3)} s`);
    steps.push(`   Height check: ${calculatedHeight.toFixed(2)} m ≈ ${h} m ✓`);
    
    steps.push("\n✅ SOLUTION FOUND!");
    steps.push(`   Required velocity = ${v0.toFixed(2)} m/s`);
    
    return { 
      solution: { angle: angleDeg, speed: v0, error, time: t, vx, vy },
      steps: steps.join('\n')
    };
  }
};