// src/utils/constants.js

export const PLANETS = {
  mars: { 
    gravity: 3.7, 
    name: 'Mars', 
    color: '#d84a3c', 
    groundColor: '#b83425', 
    bg: 'linear-gradient(180deg, #1a1410 0%, #3d1f1a 40%, #d84a3c 100%)',
    emoji: '🔴' 
  },
  earth: { 
    gravity: 9.8, 
    name: 'Earth', 
    color: '#4a90e2', 
    groundColor: '#90C695', 
    bg: 'linear-gradient(180deg, #0a1929 0%, #1e3a5f 30%, #87CEEB 70%, #a8d5ff 100%)',
    emoji: '🌍' 
  },
  moon: { 
    gravity: 1.6, 
    name: 'Moon', 
    color: '#c0c0c0', 
    groundColor: '#808080', 
    bg: 'radial-gradient(ellipse at top, #0a0e27 0%, #000000 100%)',
    emoji: '🌙' 
  },
  jupiter: { 
    gravity: 24.8, 
    name: 'Jupiter', 
    color: '#d4a574', 
    groundColor: '#b8956a', 
    bg: 'linear-gradient(180deg, #1a1410 0%, #8B6F47 40%, #d4a574 100%)',
    emoji: '🪐' 
  }
};

export const CANVAS_WIDTH = 860;
export const CANVAS_HEIGHT = 400;

export const CATAPULT_X = 80;
export const CATAPULT_Y = 340;
export const TARGET_RADIUS = 20;