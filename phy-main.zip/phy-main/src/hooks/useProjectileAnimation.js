// src/hooks/useProjectileAnimation.js (NEW FILE - Optional separate hook)

import { useRef, useEffect } from 'react';
import { CATAPULT_X, CATAPULT_Y, TARGET_RADIUS, PLANETS } from '../utils/constants';
import { calculateHitAccuracy } from '../utils/helpers';

export const useProjectileAnimation = ({
  isLaunching,
  projectile,
  setProjectile,
  setTrajectory,
  planet,
  targetPos,
  setStars,
  setHitData,
  setShowHit,
  setPlanetScores,
  setMessage,
  setTargetPos,
  resetRound,
  setShowHit: hideHit,
  gameMode,
  setGivenSpeed,
  setGivenAngle,
  setShowMissed,
  setIsLaunching,
  randomizeTarget,
  updateGivenSpeed
}) => {
  const animationRef = useRef(null);

  const animate = () => {
    if (!projectile) return;

    const g = PLANETS[planet].gravity;
    const newT = projectile.t + 0.02;

    // Calculate new position using physics equations
    const newX = CATAPULT_X + projectile.vx * newT * 10;
    const newY = CATAPULT_Y - projectile.vy * newT * 10 + 0.5 * g * newT * newT * 10;

    const updatedProjectile = { ...projectile, x: newX, y: newY, t: newT };
    setProjectile(updatedProjectile);
    
    // Add point to trajectory trail
    setTrajectory(prev => [...prev, { x: newX, y: newY }]);
    
    // Track maximum height reached
    if (!projectile.maxHeight || newY < projectile.maxHeight) {
      updatedProjectile.maxHeight = newY;
      setProjectile(updatedProjectile);
    }

    // Animate stars on moon
    if (planet === 'moon') {
      setStars(prevStars => prevStars.map(star => ({
        ...star,
        x: (star.x + star.speedX + 860) % 860,
        y: (star.y + star.speedY + 400) % 400
      })));
    }

    // Check for collision with target
    const targetCenterX = targetPos.x + TARGET_RADIUS;
    const targetCenterY = targetPos.y + TARGET_RADIUS;
    const distanceFromCenter = Math.sqrt(
      Math.pow(newX - targetCenterX, 2) + Math.pow(newY - targetCenterY, 2)
    );

    if (distanceFromCenter <= TARGET_RADIUS) {
      // HIT!
      const { points, accuracy } = calculateHitAccuracy(distanceFromCenter, TARGET_RADIUS);
      const maxHeightReached = Math.abs(CATAPULT_Y - updatedProjectile.maxHeight) / 10;
      const timeToHit = newT;
      
      setHitData({
        accuracy,
        points,
        maxHeight: maxHeightReached.toFixed(2),
        time: timeToHit.toFixed(2)
      });
      setShowHit(true);
      
      setPlanetScores(prev => ({
        ...prev,
        [planet]: prev[planet] + points
      }));
      setMessage(`${accuracy} +${points} points!`);
      
      setTimeout(() => {
        setTargetPos(randomizeTarget());
        resetRound();
        hideHit(false);
        if (gameMode === 'angle') setGivenSpeed(updateGivenSpeed(planet));
        if (gameMode === 'speed') setGivenAngle(Math.random() * 50 + 20);
      }, 3500);
      
      setIsLaunching(false);
      setProjectile(null);
      return;
    }

    // Check if projectile went off screen
    if (newY > 400 || newX > 860) {
      // MISS!
      setShowMissed(true);
      setMessage("Missed! Try again.");
      setTimeout(() => {
        resetRound();
        setShowMissed(false);
      }, 2000);
      setIsLaunching(false);
      setProjectile(null);
      return;
    }

    // Continue animation
    animationRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    if (isLaunching && projectile) {
      animationRef.current = requestAnimationFrame(animate);
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isLaunching, projectile]);

  return { animate };
};