// src/hooks/useStars.js

import { useState, useEffect } from 'react';
import { CANVAS_WIDTH } from '../utils/constants';

export const useStars = (canvasWidth = CANVAS_WIDTH, canvasHeight = 400) => {
  const [stars, setStars] = useState([]);

  // Generate initial stars
  useEffect(() => {
    const newStars = [];
    for (let i = 0; i < 200; i++) {
      newStars.push({
        x: Math.random() * canvasWidth,
        y: Math.random() * 280,
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.5 + 0.5,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        twinkleSpeed: Math.random() * 0.05 + 0.01
      });
    }
    setStars(newStars);
  }, [canvasWidth, canvasHeight]);

  // Move stars (for moon planet animation)
  const moveStars = () => {
    setStars(prevStars => 
      prevStars.map(star => ({
        ...star,
        x: (star.x + star.speedX + canvasWidth) % canvasWidth,
        y: (star.y + star.speedY + canvasHeight) % canvasHeight
      }))
    );
  };

  return { stars, setStars, moveStars };
};

// Separate hook for shooting stars effect (Moon only)
export const useShootingStars = (planet, screen) => {
  const [shootingStars, setShootingStars] = useState([]);

  useEffect(() => {
    if (planet === 'moon' && screen === 'game') {
      const interval = setInterval(() => {
        // 30% chance to create a shooting star
        if (Math.random() < 0.3) {
          setShootingStars(prev => [...prev, {
            id: Date.now(),
            x: Math.random() * 100,
            y: Math.random() * 50,
            duration: Math.random() * 2 + 1
          }]);
          
          // Remove shooting star after animation completes
          setTimeout(() => {
            setShootingStars(prev => prev.slice(1));
          }, 3000);
        }
      }, 3000);
      
      return () => clearInterval(interval);
    }
  }, [planet, screen]);

  return { shootingStars, setShootingStars };
};