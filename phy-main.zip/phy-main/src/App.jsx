// src/App.jsx

import React, { useState, useEffect } from 'react';
import MenuScreen from './components/Screens/MenuScreen';
import ModeSelectScreen from './components/Screens/ModeSelectScreen';
import GameScreen from './components/Screens/GameScreen';
import { PLANETS } from './utils/constants';
import './styles/animations.css';

export default function App() {
  const [screen, setScreen] = useState('menu');
  const [gameMode, setGameMode] = useState('playground');
  const [planet, setPlanet] = useState('mars');
  const [planetScores, setPlanetScores] = useState({
    mars: 0,
    earth: 0,
    moon: 0,
    jupiter: 0
  });

  if (screen === 'menu') {
    return <MenuScreen setScreen={setScreen} />;
  }

  if (screen === 'mode-select') {
    return <ModeSelectScreen setScreen={setScreen} setGameMode={setGameMode} />;
  }

  return (
    <GameScreen 
      gameMode={gameMode}
      planet={planet}
      setPlanet={setPlanet}
      planetScores={planetScores}
      setPlanetScores={setPlanetScores}
      setScreen={setScreen}
    />
  );
}