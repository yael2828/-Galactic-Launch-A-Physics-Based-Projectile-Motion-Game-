// src/components/UI/Controls.jsx

import React from 'react';
import { Rocket, ChevronDown, ChevronUp } from 'lucide-react';

export default function Controls({ 
  gameMode, 
  angle, 
  setAngle, 
  speed, 
  setSpeed, 
  givenAngle, 
  givenSpeed, 
  launch, 
  isLaunching, 
  message 
}) {
  return (
    <div className="p-4 space-y-4">
      <div className="flex gap-4 items-center">
        {gameMode === 'angle' && (
          <>
            <div className="flex-1 bg-gradient-to-br from-blue-100 to-blue-200 p-4 rounded-xl shadow-lg border-2 border-blue-300">
              <div className="text-center">
                <div className="text-xs font-bold text-gray-600 mb-1">GIVEN SPEED</div>
                <div className="text-3xl font-bold text-blue-600">{givenSpeed.toFixed(1)} m/s</div>
              </div>
            </div>
            <div className="flex-1 bg-gradient-to-br from-red-100 to-red-200 p-4 rounded-xl shadow-lg border-2 border-red-300">
              <div className="text-xs font-bold text-gray-600 mb-1 text-center">YOUR ANGLE</div>
              <input type="range" min="0" max="90" step="0.1" value={angle}
                     onChange={(e) => setAngle(parseFloat(e.target.value))}
                     className="w-full mb-1" style={{ height: '6px' }} />
              <div className="flex justify-between items-center gap-2">
                <button onClick={() => setAngle(Math.max(0, angle - 0.5))}
                        className="p-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors">
                  <ChevronDown size={16} />
                </button>
                <div className="text-2xl font-bold text-red-600">{angle.toFixed(1)}°</div>
                <button onClick={() => setAngle(Math.min(90, angle + 0.5))}
                        className="p-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors">
                  <ChevronUp size={16} />
                </button>
              </div>
            </div>
          </>
        )}

        {gameMode === 'speed' && (
          <>
            <div className="flex-1 bg-gradient-to-br from-blue-100 to-blue-200 p-4 rounded-xl shadow-lg border-2 border-blue-300">
              <div className="text-center">
                <div className="text-xs font-bold text-gray-600 mb-1">GIVEN ANGLE</div>
                <div className="text-3xl font-bold text-blue-600">{givenAngle.toFixed(1)}°</div>
              </div>
            </div>
            <div className="flex-1 bg-gradient-to-br from-red-100 to-red-200 p-4 rounded-xl shadow-lg border-2 border-red-300">
              <div className="text-xs font-bold text-gray-600 mb-1 text-center">YOUR SPEED</div>
              <input type="range" min="1" max="50" step="0.1" value={speed}
                     onChange={(e) => setSpeed(parseFloat(e.target.value))}
                     className="w-full mb-1" style={{ height: '6px' }} />
              <div className="flex justify-between items-center gap-2">
                <button onClick={() => setSpeed(Math.max(1, speed - 0.5))}
                        className="p-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors">
                  <ChevronDown size={16} />
                </button>
                <div className="text-2xl font-bold text-red-600">{speed.toFixed(1)} m/s</div>
                <button onClick={() => setSpeed(Math.min(50, speed + 0.5))}
                        className="p-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors">
                  <ChevronUp size={16} />
                </button>
              </div>
            </div>
          </>
        )}

        {gameMode === 'playground' && (
          <>
            <div className="flex-1 bg-gradient-to-br from-purple-100 to-purple-200 p-4 rounded-xl shadow-lg border-2 border-purple-300">
              <div className="text-xs font-bold text-gray-600 mb-1 text-center">ANGLE</div>
              <input type="range" min="0" max="90" step="0.1" value={angle}
                     onChange={(e) => setAngle(parseFloat(e.target.value))}
                     className="w-full mb-1" style={{ height: '6px' }} />
              <div className="flex justify-between items-center gap-2">
                <button onClick={() => setAngle(Math.max(0, angle - 0.5))}
                        className="p-1 bg-purple-500 text-white rounded hover:bg-purple-600 transition-colors">
                  <ChevronDown size={16} />
                </button>
                <div className="text-2xl font-bold text-purple-600">{angle.toFixed(1)}°</div>
                <button onClick={() => setAngle(Math.min(90, angle + 0.5))}
                        className="p-1 bg-purple-500 text-white rounded hover:bg-purple-600 transition-colors">
                  <ChevronUp size={16} />
                </button>
              </div>
            </div>
            <div className="flex-1 bg-gradient-to-br from-orange-100 to-orange-200 p-4 rounded-xl shadow-lg border-2 border-orange-300">
              <div className="text-xs font-bold text-gray-600 mb-1 text-center">SPEED</div>
              <input type="range" min="1" max="50" step="0.1" value={speed}
                     onChange={(e) => setSpeed(parseFloat(e.target.value))}
                     className="w-full mb-1" style={{ height: '6px' }} />
              <div className="flex justify-between items-center gap-2">
                <button onClick={() => setSpeed(Math.max(1, speed - 0.5))}
                        className="p-1 bg-orange-500 text-white rounded hover:bg-orange-600 transition-colors">
                  <ChevronDown size={16} />
                </button>
                <div className="text-2xl font-bold text-orange-600">{speed.toFixed(1)} m/s</div>
                <button onClick={() => setSpeed(Math.min(50, speed + 0.5))}
                        className="p-1 bg-orange-500 text-white rounded hover:bg-orange-600 transition-colors">
                  <ChevronUp size={16} />
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      <button onClick={launch}
              disabled={isLaunching}
              className="w-full py-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white text-xl font-bold rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2">
        <Rocket size={22} />
        {isLaunching ? 'LAUNCHING...' : 'LAUNCH'}
      </button>

      <div className="text-center p-3 bg-gradient-to-r from-blue-100 to-purple-100 rounded-xl border-2 border-blue-300">
        <div className="text-lg font-bold text-gray-700">{message}</div>
      </div>
    </div>
  );
}