// src/components/UI/HitOverlay.jsx

import React from 'react';

export default function HitOverlay({ hitData }) {
  if (!hitData) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none">
      <div className="bg-gradient-to-br from-green-500 to-emerald-600 text-white px-16 py-12 rounded-3xl shadow-2xl transform animate-bounce-in border-8 border-green-700">
        <div className="text-8xl mb-4 text-center">🎯</div>
        <div className="text-6xl font-bold text-center mb-6">CONGRATS!</div>
        <div className="text-4xl font-bold text-center mb-4">{hitData.accuracy}</div>
        <div className="text-2xl text-center space-y-2 bg-white/20 rounded-2xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between gap-4">
            <span className="font-semibold">📊 Max Height:</span>
            <span className="font-bold text-yellow-200">{hitData.maxHeight} m</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="font-semibold">⏱️ Time to Hit:</span>
            <span className="font-bold text-yellow-200">{hitData.time} s</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="font-semibold">🏆 Points:</span>
            <span className="font-bold text-yellow-200">+{hitData.points}</span>
          </div>
        </div>
      </div>
    </div>
  );
}