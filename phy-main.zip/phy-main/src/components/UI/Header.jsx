// src/components/UI/Header.jsx

import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { PLANETS } from '../../utils/constants';

export default function Header({ planet, setPlanet, planetScores, setScreen }) {
  return (
    <div className="flex-shrink-0 bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 px-4 py-3 flex justify-between items-center shadow-lg">
      <button onClick={() => setScreen('mode-select')}
              className="flex items-center gap-2 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-bold transition-all transform hover:scale-105 shadow-lg">
        <ArrowLeft size={18} /> BACK
      </button>
      
      <div className="flex gap-2">
        {Object.entries(PLANETS).map(([key, data]) => (
          <button key={key}
                  onClick={() => setPlanet(key)}
                  className={`px-3 py-2 rounded-lg font-bold transition-all transform ${
                    planet === key ? 'bg-blue-500 text-white scale-110 shadow-lg' : 'bg-gray-700 text-gray-300 hover:bg-gray-600 hover:scale-105'
                  }`}>
            <div className="text-2xl">{data.emoji}</div>
            <div className="text-xs">{data.name}</div>
            <div className="text-xs">{data.gravity} m/s²</div>
            <div className="text-xs font-bold text-yellow-300">🏆 {planetScores[key]}</div>
          </button>
        ))}
      </div>

      <div className="text-white text-right">
        <div className="text-3xl font-bold">🏆 {planetScores[planet]}</div>
        <div className="text-xs">{PLANETS[planet].name} Score</div>
      </div>
    </div>
  );
}