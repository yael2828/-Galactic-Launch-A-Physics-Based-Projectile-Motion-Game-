// src/components/UI/Calculator.jsx

import React, { useRef } from 'react';
import { Calculator as CalcIcon, Target, ChevronDown } from 'lucide-react';
import { PLANETS, CATAPULT_X, CATAPULT_Y, TARGET_RADIUS } from '../../utils/constants';
import { PhysicsCalculator } from '../../utils/PhysicsCalculator';

export default function Calculator({ 
  showCalc, 
  setShowCalc, 
  planet, 
  gameMode, 
  givenSpeed, 
  givenAngle,
  targetPos,
  calculatedValues,
  setCalculatedValues,
  calcResult,
  setCalcResult,
  setAngle,
  setSpeed,
  setMessage
}) {
  const distanceInputRef = useRef(null);
  const heightInputRef = useRef(null);

  const calculateTrajectory = () => {
    const distance = parseFloat(distanceInputRef.current?.value || 0);
    const height = parseFloat(heightInputRef.current?.value || 0);

    if (distance <= 0 || height < 0) {
      setCalcResult("⚠️ Please enter valid distance (>0) and height (≥0)");
      return;
    }

    const g = PLANETS[planet].gravity;
    let result;

    if (gameMode === 'angle') {
      result = PhysicsCalculator.calculateAngleFromVelocity(distance, height, givenSpeed, g);
      if (result.solutions.length > 0) {
        setCalculatedValues(result.solutions[0]);
      } else {
        setCalculatedValues(null);
      }
      setCalcResult(result.steps);
    } else if (gameMode === 'speed') {
      result = PhysicsCalculator.calculateVelocityFromAngle(distance, height, givenAngle, g);
      if (result.solution) {
        setCalculatedValues(result.solution);
      } else {
        setCalculatedValues(null);
      }
      setCalcResult(result.steps);
    } else {
      result = PhysicsCalculator.calculateAngleFromVelocity(distance, height, 25, g);
      if (result.solutions.length > 0) {
        setCalculatedValues(result.solutions[0]);
      } else {
        setCalculatedValues(null);
      }
      setCalcResult(result.steps);
    }
  };

  const applyCalculatedValues = () => {
    if (!calculatedValues) return;
    if (gameMode === 'playground') {
      setAngle(calculatedValues.angle);
      setSpeed(calculatedValues.speed);
    } else if (gameMode === 'angle') {
      setAngle(calculatedValues.angle);
    } else if (gameMode === 'speed') {
      setSpeed(calculatedValues.speed);
    }
    setMessage("✅ Calculator values applied!");
  };

  const autoFillTarget = () => {
    const centerX = targetPos.x + TARGET_RADIUS;
    const centerY = targetPos.y + TARGET_RADIUS;
    const distance = Math.round((centerX - CATAPULT_X) / 10 * 10) / 10;
    const height = Math.round((CATAPULT_Y - centerY) / 10 * 10) / 10;
    
    if (distanceInputRef.current) distanceInputRef.current.value = distance;
    if (heightInputRef.current) heightInputRef.current.value = height;
    setMessage("✅ Target values auto-filled! Click Calculate.");
  };

  return (
    <div className="bg-gradient-to-br from-indigo-100 to-blue-200 rounded-xl shadow-lg overflow-hidden border-2 border-indigo-300">
      <button onClick={() => setShowCalc(!showCalc)}
              className="w-full p-3 bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-bold flex items-center justify-between hover:from-indigo-700 hover:to-blue-700 transition-colors">
        <div className="flex items-center gap-2">
          <CalcIcon size={20} />
          🧮 Trajectory Calculator
        </div>
        <ChevronDown size={20} className={`transform transition-transform ${showCalc ? 'rotate-180' : ''}`} />
      </button>

      {showCalc && (
        <div className="p-4 space-y-3">
          <div className="bg-white p-2 rounded-lg shadow-inner text-center">
            <div className="font-bold text-gray-700 text-sm">
              🪐 {PLANETS[planet].name} | Gravity: {PLANETS[planet].gravity} m/s²
            </div>
          </div>

          <button onClick={autoFillTarget}
                  className="w-full py-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-bold rounded-lg flex items-center justify-center gap-2 transition-colors text-sm">
            <Target size={16} />
            📍 Auto-Fill Target
          </button>

          <div className="flex gap-3">
            <div className="flex-1">
              <label className="block text-xs font-bold text-gray-700 mb-1">Distance (m)</label>
              <input ref={distanceInputRef} type="number" step="0.1"
                     className="w-full p-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none font-bold" />
            </div>
            <div className="flex-1">
              <label className="block text-xs font-bold text-gray-700 mb-1">Height (m)</label>
              <input ref={heightInputRef} type="number" step="0.1"
                     className="w-full p-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none font-bold" />
            </div>
          </div>

          <button onClick={calculateTrajectory}
                  className="w-full py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold rounded-lg transition-colors">
            Calculate
          </button>

          {calcResult && (
            <div className="bg-white p-3 rounded-lg border-2 border-indigo-300 shadow-inner max-h-96 overflow-y-auto">
              <pre className="whitespace-pre-wrap text-xs font-mono text-gray-800 leading-relaxed">
                {calcResult}
              </pre>
            </div>
          )}

          {calculatedValues && (
            <button onClick={applyCalculatedValues}
                    className="w-full py-2 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold rounded-lg transition-colors">
              ✅ Apply Values
            </button>
          )}
        </div>
      )}
    </div>
  );
}