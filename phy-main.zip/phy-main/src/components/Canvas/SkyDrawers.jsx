// src/components/Canvas/SkyDrawers.jsx

import { CANVAS_WIDTH } from '../../utils/constants';

export const drawMoonStars = (ctx, stars) => {
  stars.forEach((star, index) => {
    ctx.beginPath();
    ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
    const twinkle = Math.sin(Date.now() * star.twinkleSpeed) * 0.3 + 0.7;
    ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity * twinkle})`;
    ctx.fill();
    
    if (index % 20 === 0) {
      ctx.fillStyle = `rgba(135, 206, 250, ${star.opacity * twinkle})`;
      ctx.fill();
    }
  });
  
  // Earth in the sky
  ctx.fillStyle = 'rgba(100, 149, 237, 0.6)';
  ctx.beginPath();
  ctx.arc(700, 100, 15, 0, Math.PI * 2);
  ctx.fill();
  
  // Mars in the sky
  ctx.fillStyle = 'rgba(65, 105, 225, 0.5)';
  ctx.beginPath();
  ctx.arc(150, 80, 25, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(34, 139, 34, 0.4)';
  ctx.beginPath();
  ctx.arc(145, 75, 12, 0, Math.PI * 2);
  ctx.fill();
};

export const drawEarthSky = (ctx) => {
  // Sun
  const gradient = ctx.createRadialGradient(750, 80, 10, 750, 80, 60);
  gradient.addColorStop(0, '#FFF4A3');
  gradient.addColorStop(0.5, '#FFD700');
  gradient.addColorStop(1, 'rgba(255, 165, 0, 0.3)');
  ctx.beginPath();
  ctx.arc(750, 80, 50, 0, Math.PI * 2);
  ctx.fillStyle = gradient;
  ctx.fill();
  
  // Sun rays
  for (let i = 0; i < 12; i++) {
    const angle = (i * 30) * Math.PI / 180;
    ctx.beginPath();
    ctx.moveTo(750 + Math.cos(angle) * 55, 80 + Math.sin(angle) * 55);
    ctx.lineTo(750 + Math.cos(angle) * 70, 80 + Math.sin(angle) * 70);
    ctx.strokeStyle = 'rgba(255, 215, 0, 0.6)';
    ctx.lineWidth = 3;
    ctx.stroke();
  }
  
  // Clouds
  drawCloud(ctx, 150, 100, 1);
  drawCloud(ctx, 400, 80, 0.8);
  drawCloud(ctx, 650, 120, 0.9);
  
  // Birds
  drawBird(ctx, 250, 150);
  drawBird(ctx, 280, 160);
};

export const drawMarsSky = (ctx) => {
  // Mars terrain features
  ctx.fillStyle = 'rgba(139, 69, 19, 0.3)';
  ctx.beginPath();
  ctx.moveTo(0, 250);
  ctx.quadraticCurveTo(200, 200, 400, 240);
  ctx.quadraticCurveTo(600, 220, 860, 260);
  ctx.lineTo(860, 360);
  ctx.lineTo(0, 360);
  ctx.fill();
  
  // Dust clouds
  ctx.fillStyle = 'rgba(212, 74, 60, 0.2)';
  ctx.beginPath();
  ctx.ellipse(200, 280, 100, 30, 0, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.beginPath();
  ctx.ellipse(600, 300, 120, 35, 0, 0, Math.PI * 2);
  ctx.fill();
  
  // Phobos (Mars moon)
  const gradient = ctx.createRadialGradient(100, 100, 5, 100, 100, 25);
  gradient.addColorStop(0, '#FFE4B5');
  gradient.addColorStop(1, 'rgba(255, 228, 181, 0.3)');
  ctx.beginPath();
  ctx.arc(100, 100, 25, 0, Math.PI * 2);
  ctx.fillStyle = gradient;
  ctx.fill();
};

export const drawJupiterSky = (ctx) => {
  const bands = [
    { y: 100, height: 40, color: 'rgba(194, 147, 99, 0.3)' },
    { y: 150, height: 50, color: 'rgba(139, 90, 43, 0.25)' },
    { y: 210, height: 45, color: 'rgba(160, 120, 80, 0.3)' },
    { y: 260, height: 40, color: 'rgba(180, 140, 100, 0.2)' }
  ];
  
  bands.forEach(band => {
    ctx.fillStyle = band.color;
    ctx.fillRect(0, band.y, CANVAS_WIDTH, band.height);
    
    // Atmospheric turbulence
    ctx.strokeStyle = `rgba(212, 165, 116, 0.2)`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let x = 0; x < CANVAS_WIDTH; x += 50) {
      ctx.moveTo(x, band.y + band.height / 2);
      ctx.quadraticCurveTo(x + 25, band.y + band.height / 2 - 10, x + 50, band.y + band.height / 2);
    }
    ctx.stroke();
  });
  
  // Great Red Spot
  const spotGradient = ctx.createRadialGradient(700, 200, 10, 700, 200, 40);
  spotGradient.addColorStop(0, 'rgba(180, 60, 50, 0.4)');
  spotGradient.addColorStop(1, 'rgba(139, 45, 35, 0.2)');
  ctx.beginPath();
  ctx.ellipse(700, 200, 40, 30, 0, 0, Math.PI * 2);
  ctx.fillStyle = spotGradient;
  ctx.fill();
};

const drawCloud = (ctx, x, y, scale) => {
  ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
  ctx.beginPath();
  ctx.arc(x, y, 20 * scale, 0, Math.PI * 2);
  ctx.arc(x + 20 * scale, y - 5 * scale, 25 * scale, 0, Math.PI * 2);
  ctx.arc(x + 40 * scale, y, 20 * scale, 0, Math.PI * 2);
  ctx.arc(x + 30 * scale, y + 10 * scale, 20 * scale, 0, Math.PI * 2);
  ctx.fill();
};

const drawBird = (ctx, x, y) => {
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x - 10, y);
  ctx.quadraticCurveTo(x - 5, y - 5, x, y);
  ctx.quadraticCurveTo(x + 5, y - 5, x + 10, y);
  ctx.stroke();
};