// src/components/Canvas/Canvas.jsx

import React, { useRef, useEffect } from 'react';
import { CANVAS_WIDTH, CANVAS_HEIGHT, CATAPULT_X, CATAPULT_Y, TARGET_RADIUS, PLANETS } from '../../utils/constants';
import { drawMoonStars, drawEarthSky, drawMarsSky, drawJupiterSky } from './SkyDrawers';
import { drawCannon } from './CannonDrawer';
import { drawTarget, drawGround } from './TargetDrawer';
import { drawProjectile, drawTrajectory } from './ProjectileDrawer';

export default function Canvas({ 
  planet, 
  angle, 
  gameMode,
  givenAngle,
  targetPos, 
  projectile, 
  stars, 
  trajectory 
}) {
  const canvasRef = useRef(null);

  useEffect(() => {
    drawScene();
  }, [planet, angle, givenAngle, targetPos, projectile, stars, trajectory]);

  const drawScene = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw sky based on planet
    if (planet === 'moon') {
      drawMoonStars(ctx, stars);
    } else if (planet === 'earth') {
      drawEarthSky(ctx);
    } else if (planet === 'mars') {
      drawMarsSky(ctx);
    } else if (planet === 'jupiter') {
      drawJupiterSky(ctx);
    }

    // Draw ground
    drawGround(ctx, PLANETS[planet].groundColor, planet);
    
    // Draw target
    drawTarget(ctx, targetPos, TARGET_RADIUS, CATAPULT_X, CATAPULT_Y, planet);
    
    // Draw trajectory
    drawTrajectory(ctx, trajectory);
    
    // Draw cannon
    const currentAngle = gameMode === 'speed' ? givenAngle : angle;
    drawCannon(ctx, CATAPULT_X, CATAPULT_Y, currentAngle);
    
    // Draw projectile
    if (projectile) {
      drawProjectile(ctx, projectile);
    }
  };

  return (
    <div className="flex-shrink-0 flex justify-center" 
         style={{ background: PLANETS[planet].bg }}>
      <canvas ref={canvasRef} width={CANVAS_WIDTH} height={CANVAS_HEIGHT}
              className="border-b-4 border-gray-800" />
    </div>
  );
}