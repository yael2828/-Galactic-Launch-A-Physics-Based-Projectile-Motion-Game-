// src/components/Canvas/ProjectileDrawer.jsx

export const drawProjectile = (ctx, projectile) => {
  if (!projectile) return;
  
  ctx.fillStyle = '#333';
  ctx.strokeStyle = '#666';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(projectile.x, projectile.y, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
};

export const drawTrajectory = (ctx, trajectory) => {
  if (trajectory.length < 2) return;

  // Draw trajectory line
  ctx.strokeStyle = 'rgba(255, 255, 0, 0.6)';
  ctx.lineWidth = 3;
  ctx.setLineDash([5, 5]);
  ctx.beginPath();
  ctx.moveTo(trajectory[0].x, trajectory[0].y);
  for (let i = 1; i < trajectory.length; i++) {
    ctx.lineTo(trajectory[i].x, trajectory[i].y);
  }
  ctx.stroke();
  ctx.setLineDash([]);
  
  // Draw trajectory points (dots along the path)
  trajectory.forEach((point, index) => {
    if (index % 3 === 0) {
      ctx.fillStyle = 'rgba(255, 215, 0, 0.8)';
      ctx.beginPath();
      ctx.arc(point.x, point.y, 3, 0, Math.PI * 2);
      ctx.fill();
    }
  });
};