// src/components/Canvas/TargetDrawer.jsx

export const drawTarget = (ctx, targetPos, targetRadius, catapultX, catapultY, planet) => {
  const centerX = targetPos.x + targetRadius;
  const centerY = targetPos.y + targetRadius;

  // Target stand
  ctx.fillStyle = '#666';
  ctx.fillRect(centerX - targetRadius - 5, centerY + targetRadius, targetRadius * 2 + 10, 10);

  // Target circles (bullseye pattern)
  ctx.fillStyle = '#ff4444';
  ctx.beginPath();
  ctx.arc(centerX, centerY, targetRadius, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = 'white';
  ctx.beginPath();
  ctx.arc(centerX, centerY, targetRadius * 0.7, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#ff4444';
  ctx.beginPath();
  ctx.arc(centerX, centerY, targetRadius * 0.4, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = 'white';
  ctx.beginPath();
  ctx.arc(centerX, centerY, targetRadius * 0.15, 0, Math.PI * 2);
  ctx.fill();

  // Distance and height labels
  const distance = Math.round((centerX - catapultX) / 10);
  const heightDiff = Math.round((catapultY - centerY) / 10);
  const textColor = planet === 'moon' ? 'white' : '#333';

  // Distance line (horizontal)
  ctx.strokeStyle = textColor;
  ctx.setLineDash([5, 5]);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(catapultX, catapultY + 40);
  ctx.lineTo(centerX, catapultY + 40);
  ctx.stroke();

  // Distance text
  ctx.fillStyle = textColor;
  ctx.font = 'bold 12px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(`${distance}m`, (catapultX + centerX) / 2, catapultY + 30);

  // Height line (vertical)
  ctx.beginPath();
  ctx.moveTo(centerX + targetRadius + 15, centerY);
  ctx.lineTo(centerX + targetRadius + 15, catapultY);
  ctx.stroke();

  // Height text
  ctx.save();
  ctx.translate(centerX + targetRadius + 30, (centerY + catapultY) / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText(`${heightDiff}m`, 0, 0);
  ctx.restore();

  ctx.setLineDash([]);
};

export const drawGround = (ctx, groundColor, planet) => {
  // Ground segments
  for (let i = 0; i < 20; i++) {
    const x = i * 50;
    const offset = Math.random() * 10;
    ctx.fillStyle = groundColor;
    ctx.fillRect(x, 360 + offset, 40, 5);
  }

  // Moon craters
  if (planet === 'moon') {
    ctx.fillStyle = '#808080';
    ctx.beginPath();
    ctx.ellipse(200, 370, 30, 10, 0, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = '#707070';
    ctx.beginPath();
    ctx.ellipse(205, 368, 15, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = '#808080';
    ctx.beginPath();
    ctx.ellipse(450, 375, 25, 8, 0, 0, Math.PI * 2);
    ctx.fill();
  }
};