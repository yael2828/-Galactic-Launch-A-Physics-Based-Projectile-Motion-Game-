// src/components/Canvas/CannonDrawer.jsx

export const drawCannon = (ctx, catapultX, catapultY, angle) => {
  const angleRad = angle * Math.PI / 180;
  
  // Draw wooden base/carriage
  ctx.fillStyle = '#8B4513';
  ctx.fillRect(catapultX - 35, catapultY + 5, 70, 15);
  
  // Draw wheel (large wooden wheel with spokes)
  const wheelRadius = 18;
  const wheelX = catapultX - 20;
  const wheelY = catapultY + 25;
  
  // Wheel rim
  ctx.fillStyle = '#654321';
  ctx.strokeStyle = '#4a3010';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(wheelX, wheelY, wheelRadius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  
  // Wheel spokes
  ctx.strokeStyle = '#4a3010';
  ctx.lineWidth = 2;
  for (let i = 0; i < 8; i++) {
    const spokeAngle = (i * Math.PI) / 4;
    ctx.beginPath();
    ctx.moveTo(wheelX, wheelY);
    ctx.lineTo(
      wheelX + Math.cos(spokeAngle) * wheelRadius,
      wheelY + Math.sin(spokeAngle) * wheelRadius
    );
    ctx.stroke();
  }
  
  // Wheel hub
  ctx.fillStyle = '#2c2c2c';
  ctx.beginPath();
  ctx.arc(wheelX, wheelY, 5, 0, Math.PI * 2);
  ctx.fill();
  
  // Draw pivot point on carriage
  ctx.fillStyle = '#2c2c2c';
  ctx.beginPath();
  ctx.arc(catapultX, catapultY + 12, 6, 0, Math.PI * 2);
  ctx.fill();
  
  // Draw cannon barrel (black metal) - rotates from the carriage
  const barrelLength = 50;
  const barrelWidth = 16;
  
  // Barrel body
  ctx.save();
  ctx.translate(catapultX, catapultY + 12);
  ctx.rotate(-angleRad);
  
  // Main barrel
  ctx.fillStyle = '#2c2c2c';
  ctx.fillRect(0, -barrelWidth / 2, barrelLength, barrelWidth);
  
  // Barrel bands (metal rings)
  ctx.fillStyle = '#1a1a1a';
  ctx.fillRect(5, -barrelWidth / 2, 3, barrelWidth);
  ctx.fillRect(barrelLength - 8, -barrelWidth / 2, 3, barrelWidth);
  ctx.fillRect(barrelLength / 2, -barrelWidth / 2, 3, barrelWidth);
  
  // Barrel opening
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.arc(barrelLength, 0, barrelWidth / 2 - 1, 0, Math.PI * 2);
  ctx.fill();
  
  // Add highlight to show metal shine
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.fillRect(2, -barrelWidth / 2 + 2, barrelLength - 4, barrelWidth / 3);
  
  ctx.restore();
  
  // Draw cannonballs stack
  const ballX = catapultX + 35;
  const ballY = catapultY + 15;
  const ballRadius = 6;
  
  // Bottom row (3 balls)
  ctx.fillStyle = '#2c2c2c';
  ctx.strokeStyle = '#1a1a1a';
  ctx.lineWidth = 1;
  
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(ballX + (i - 1) * ballRadius * 2, ballY, ballRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    
    // Add shine to cannonballs
    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.beginPath();
    ctx.arc(ballX + (i - 1) * ballRadius * 2 - 2, ballY - 2, ballRadius / 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#2c2c2c';
  }
  
  // Top row (2 balls)
  for (let i = 0; i < 2; i++) {
    ctx.fillStyle = '#2c2c2c';
    ctx.beginPath();
    ctx.arc(ballX + (i - 0.5) * ballRadius * 2, ballY - ballRadius * 1.7, ballRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    
    // Add shine
    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.beginPath();
    ctx.arc(ballX + (i - 0.5) * ballRadius * 2 - 2, ballY - ballRadius * 1.7 - 2, ballRadius / 3, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // Top ball
  ctx.fillStyle = '#2c2c2c';
  ctx.beginPath();
  ctx.arc(ballX, ballY - ballRadius * 3.4, ballRadius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  
  // Add shine
  ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
  ctx.beginPath();
  ctx.arc(ballX - 2, ballY - ballRadius * 3.4 - 2, ballRadius / 3, 0, Math.PI * 2);
  ctx.fill();
};