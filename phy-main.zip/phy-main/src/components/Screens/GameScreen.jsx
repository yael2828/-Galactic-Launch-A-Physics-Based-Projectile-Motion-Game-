// src/components/Screens/GameScreen.jsx

import React, { useState, useEffect, useRef } from 'react';
import Header from '../UI/Header';
import Canvas from '../Canvas/Canvas';
import Controls from '../UI/Controls';
import Calculator from '../UI/Calculator';
import HitOverlay from '../UI/HitOverlay';
import MissedOverlay from '../UI/MissedOverlay';
import ShootingStars from '../Effects/ShootingStars';
import { PLANETS, CATAPULT_X, CATAPULT_Y, TARGET_RADIUS } from '../../utils/constants';
import { updateGivenSpeed, randomizeTarget, generateStars, calculateHitAccuracy } from '../../utils/helpers';

export default function GameScreen({ gameMode, planet, setPlanet, planetScores, setPlanetScores, setScreen }) {
  const [angle, setAngle] = useState(45);
  const [speed, setSpeed] = useState(20);
  const [givenAngle, setGivenAngle] = useState(45);
  const [givenSpeed, setGivenSpeed] = useState(25);
  const [targetPos, setTargetPos] = useState({ x: 650, y: 200 });
  const [isLaunching, setIsLaunching] = useState(false);
  const [projectile, setProjectile] = useState(null);
  const [message, setMessage] = useState('Aim for the target!');
  const [stars, setStars] = useState([]);
  const [showCalc, setShowCalc] = useState(true);
  const [calcResult, setCalcResult] = useState('');
  const [calculatedValues, setCalculatedValues] = useState(null);
  const [shootingStars, setShootingStars] = useState([]);
  const [showMissed, setShowMissed] = useState(false);
  const [showHit, setShowHit] = useState(false);
  const [hitData, setHitData] = useState(null);
  const [trajectory, setTrajectory] = useState([]);
  
  const animationRef = useRef(null);

  useEffect(() => {
    setStars(generateStars(860, 400));
    setTargetPos(randomizeTarget());
    setGivenSpeed(updateGivenSpeed(planet));
  }, []);

  useEffect(() => {
    if (gameMode === 'angle') {
      setGivenSpeed(updateGivenSpeed(planet));
    }
  }, [planet, gameMode]);

  useEffect(() => {
    if (isLaunching && projectile) {
      animationRef.current = requestAnimationFrame(animate);
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isLaunching, projectile]);

  useEffect(() => {
    if (planet === 'moon') {
      const interval = setInterval(() => {
        if (Math.random() < 0.3) {
          setShootingStars(prev => [...prev, {
            id: Date.now(),
            x: Math.random() * 100,
            y: Math.random() * 50,
            duration: Math.random() * 2 + 1
          }]);
          
          setTimeout(() => {
            setShootingStars(prev => prev.slice(1));
          }, 3000);
        }
      }, 3000);
      
      return () => clearInterval(interval);
    }
  }, [planet]);

  const animate = () => {
    if (!projectile) return;

    const g = PLANETS[planet].gravity;
    const newT = projectile.t + 0.02;

    const newX = CATAPULT_X + projectile.vx * newT * 10;
    const newY = CATAPULT_Y - projectile.vy * newT * 10 + 0.5 * g * newT * newT * 10;

    const updatedProjectile = { ...projectile, x: newX, y: newY, t: newT };
    setProjectile(updatedProjectile);
    
    setTrajectory(prev => [...prev, { x: newX, y: newY }]);
    
    if (!projectile.maxHeight || newY < projectile.maxHeight) {
      updatedProjectile.maxHeight = newY;
      setProjectile(updatedProjectile);
    }

    if (planet === 'moon') {
      setStars(prevStars => prevStars.map(star => ({
        ...star,
        x: (star.x + star.speedX + 860) % 860,
        y: (star.y + star.speedY + 400) % 400
      })));
    }

    const targetCenterX = targetPos.x + TARGET_RADIUS;
    const targetCenterY = targetPos.y + TARGET_RADIUS;
    const distanceFromCenter = Math.sqrt(
      Math.pow(newX - targetCenterX, 2) + Math.pow(newY - targetCenterY, 2)
    );

    if (distanceFromCenter <= TARGET_RADIUS) {
      const { points, accuracy } = calculateHitAccuracy(distanceFromCenter, TARGET_RADIUS);
      const maxHeightReached = Math.abs(CATAPULT_Y - updatedProjectile.maxHeight) / 10;
      const timeToHit = newT;
      
      setHitData({
        accuracy,
        points,
        maxHeight: maxHeightReached.toFixed(2),
        time: timeToHit.toFixed(2)
      });
      setShowHit(true);
      
      setPlanetScores(prev => ({
        ...prev,
        [planet]: prev[planet] + points
      }));
      setMessage(`${accuracy} +${points} points!`);
      setTimeout(() => {
        setTargetPos(randomizeTarget());
        resetRound();
        setShowHit(false);
        if (gameMode === 'angle') setGivenSpeed(updateGivenSpeed(planet));
        if (gameMode === 'speed') setGivenAngle(Math.random() * 50 + 20);
      }, 3500);
      setIsLaunching(false);
      setProjectile(null);
      return;
    }

    if (newY > 400 || newX > 860) {
      setShowMissed(true);
      setMessage("Missed! Try again.");
      setTimeout(() => {
        resetRound();
        setShowMissed(false);
      }, 2000);
      setIsLaunching(false);
      setProjectile(null);
      return;
    }

    animationRef.current = requestAnimationFrame(animate);
  };

  const launch = () => {
    if (isLaunching) return;

    setIsLaunching(true);
    setMessage("Firing...");
    setTrajectory([]);

    const launchAngle = gameMode === 'speed' ? givenAngle : angle;
    const launchSpeed = gameMode === 'angle' ? givenSpeed : speed;
    const angleRad = launchAngle * Math.PI / 180;

    setProjectile({
      x: CATAPULT_X,
      y: CATAPULT_Y,
      vx: launchSpeed * Math.cos(angleRad),
      vy: launchSpeed * Math.sin(angleRad),
      t: 0,
      maxHeight: CATAPULT_Y
    });
  };

  const resetRound = () => {
    setProjectile(null);
    setIsLaunching(false);
    setMessage("Aim for the target!");
    setTrajectory([]);
  };

  return (
    <div className="h-screen overflow-hidden flex flex-col" 
         style={{ background: PLANETS[planet].bg }}>
      
      <ShootingStars shootingStars={shootingStars} />

      <Header 
        planet={planet}
        setPlanet={setPlanet}
        planetScores={planetScores}
        setScreen={setScreen}
      />

      <div className="flex-1 overflow-y-auto">
        <Canvas 
          planet={planet}
          angle={angle}
          gameMode={gameMode}
          givenAngle={givenAngle}
          targetPos={targetPos}
          projectile={projectile}
          stars={stars}
          trajectory={trajectory}
        />

        {showMissed && <MissedOverlay />}
        {showHit && <HitOverlay hitData={hitData} />}

        <div className="bg-white/95 backdrop-blur-sm">
          <Controls 
            gameMode={gameMode}
            angle={angle}
            setAngle={setAngle}
            speed={speed}
            setSpeed={setSpeed}
            givenAngle={givenAngle}
            givenSpeed={givenSpeed}
            launch={launch}
            isLaunching={isLaunching}
            message={message}
          />
          
          <div className="px-4 pb-4">
            <Calculator 
              showCalc={showCalc}
              setShowCalc={setShowCalc}
              planet={planet}
              gameMode={gameMode}
              givenSpeed={givenSpeed}
              givenAngle={givenAngle}
              targetPos={targetPos}
              calculatedValues={calculatedValues}
              setCalculatedValues={setCalculatedValues}
              calcResult={calcResult}
              setCalcResult={setCalcResult}
              setAngle={setAngle}
              setSpeed={setSpeed}
              setMessage={setMessage}
            />
          </div>
        </div>
      </div>
    </div>
  );
}