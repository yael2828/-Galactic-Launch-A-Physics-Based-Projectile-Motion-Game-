// src/components/Screens/MenuScreen.jsx

import React from 'react';

export default function MenuScreen({ setScreen }) {
  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden" 
         style={{ background: 'linear-gradient(180deg, #0a1929 0%, #1e3a5f 50%, #87CEEB 100%)' }}>
      <div className="absolute inset-0">
        {[...Array(100)].map((_, i) => (
          <div key={i} className="absolute animate-twinkle"
               style={{
                 left: `${Math.random() * 100}%`,
                 top: `${Math.random() * 60}%`,
                 width: `${Math.random() * 3 + 1}px`,
                 height: `${Math.random() * 3 + 1}px`,
                 background: 'white',
                 borderRadius: '50%',
                 animationDelay: `${Math.random() * 3}s`,
                 opacity: Math.random() * 0.7 + 0.3
               }}>
          </div>
        ))}
      </div>
      
      <div className="text-center z-10 relative">
        <div className="mb-16 transform hover:scale-105 transition-transform duration-300">
          <h1 className="text-8xl font-bold mb-4" 
              style={{ 
                color: '#4a4a4a',
                textShadow: '5px 5px 0px rgba(0,0,0,0.3), 10px 10px 0px rgba(0,0,0,0.1)'
              }}>
            PLANETARY PROJECTILE
          </h1>
          <h2 className="text-6xl font-bold"
              style={{
                color: '#FFD700',
                textShadow: '4px 4px 0px #B8860B'
              }}>
            GAME
          </h2>
        </div>
        
        <button onClick={() => setScreen('mode-select')}
                className="px-20 py-8 text-4xl font-bold text-white rounded-2xl shadow-2xl transform hover:scale-110 hover:shadow-3xl transition-all duration-300 relative overflow-hidden group"
                style={{ backgroundColor: '#7cb342' }}>
          <span className="relative z-10">🚀 START GAME</span>
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent group-hover:from-black/40"></div>
        </button>
      </div>
    </div>
  );
}