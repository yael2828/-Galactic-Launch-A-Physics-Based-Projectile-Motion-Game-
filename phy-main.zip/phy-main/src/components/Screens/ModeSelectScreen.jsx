// src/components/Screens/ModeSelectScreen.jsx

import React from 'react';

export default function ModeSelectScreen({ setScreen, setGameMode }) {
  const modes = [
    { 
      mode: 'angle', 
      title: 'ANGLE\nMODE', 
      color: 'from-green-500 to-green-600', 
      hoverColor: 'from-green-600 to-green-700', 
      desc: 'Speed is given\nCalculate the angle', 
      icon: '📐' 
    },
    { 
      mode: 'speed', 
      title: 'SPEED\nMODE', 
      color: 'from-red-500 to-red-600', 
      hoverColor: 'from-red-600 to-red-700', 
      desc: 'Angle is given\nCalculate the speed', 
      icon: '⚡' 
    },
    { 
      mode: 'playground', 
      title: 'PLAYGROUND\nMODE', 
      color: 'from-blue-500 to-blue-600', 
      hoverColor: 'from-blue-600 to-blue-700', 
      desc: 'Free play\nAdjust both values', 
      icon: '🎮' 
    }
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-8"
         style={{ background: 'linear-gradient(180deg, #0a1929 0%, #1e3a5f 50%, #87CEEB 100%)' }}>
      
      <div className="absolute inset-0">
        {[...Array(150)].map((_, i) => (
          <div key={i} className="absolute"
               style={{
                 left: `${Math.random() * 100}%`,
                 top: `${Math.random() * 100}%`,
                 width: `${Math.random() * 3 + 1}px`,
                 height: `${Math.random() * 3 + 1}px`,
                 background: 'white',
                 borderRadius: '50%',
                 opacity: Math.random() * 0.8 + 0.2,
                 animation: `twinkle ${Math.random() * 3 + 2}s ease-in-out infinite`,
                 animationDelay: `${Math.random() * 2}s`
               }}>
          </div>
        ))}
      </div>

      <div className="max-w-7xl w-full relative z-10">
        <h1 className="text-7xl font-bold text-center mb-20 text-white"
            style={{ textShadow: '4px 4px 8px rgba(0,0,0,0.5)' }}>
          SELECT GAME MODE
        </h1>
        
        <div className="flex flex-row justify-center items-stretch gap-6">
          {modes.map(({ mode, title, color, hoverColor, desc, icon }) => (
            <div key={mode} className="flex-1 max-w-sm">
              <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 shadow-2xl transform hover:scale-105 hover:-translate-y-2 transition-all duration-300 h-full flex flex-col">
                <div className="text-8xl mb-6 text-center animate-bounce-slow">{icon}</div>
                <button onClick={() => { setGameMode(mode); setScreen('game'); }}
                        className={`w-full py-6 px-4 rounded-2xl text-white font-bold text-2xl mb-6 shadow-xl hover:shadow-2xl transition-all bg-gradient-to-br ${color} hover:${hoverColor}`}>
                  <div className="whitespace-pre-line leading-tight">{title}</div>
                </button>
                <p className="text-center text-gray-700 whitespace-pre-line font-semibold text-lg leading-relaxed flex-grow flex items-center justify-center">
                  {desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}