// src/components/Effects/ShootingStars.jsx

import React from 'react';

export default function ShootingStars({ shootingStars }) {
  return (
    <>
      {shootingStars.map(star => (
        <div key={star.id}
             className="absolute pointer-events-none"
             style={{
               left: `${star.x}%`,
               top: `${star.y}%`,
               animation: `shootingStar ${star.duration}s linear`
             }}>
          <div className="w-1 h-1 bg-white rounded-full shadow-lg"
               style={{ boxShadow: '0 0 10px 2px rgba(255,255,255,0.8)' }}></div>
        </div>
      ))}
    </>
  );
}